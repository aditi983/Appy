This is the updated code of Appy, with all dependencies fixed.
